<?php
namespace Modules\ExampleModule\Models\Scopes;
use Illuminate\Database\Eloquent\Builder;use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Scope;
class TenantScope implements Scope{public function apply(Builder $builder,Model $model):void{if(function_exists('tenant_company_id') && tenant_company_id()){ $builder->where($model->getTable().'.company_id',tenant_company_id());}}}
