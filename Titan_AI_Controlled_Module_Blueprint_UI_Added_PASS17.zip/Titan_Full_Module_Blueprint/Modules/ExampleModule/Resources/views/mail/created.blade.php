Example record created.
